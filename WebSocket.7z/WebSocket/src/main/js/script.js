var conn = new WebSocket('ws://10.0.0.47:55000');
// var conn = new WebSocket('ws://10.0.0.47:8080');
// var conn = new WebSocket('ws://localhost:8080');
conn.onopen = function(e) {
    console.log("Connection established!");
    conn.send('Hello World');
};

conn.onmessage = function(e) {
    console.log(e.data);
    $( "body" ).append( e.data );

};

