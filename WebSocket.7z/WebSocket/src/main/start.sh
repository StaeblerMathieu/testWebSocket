#! /bin/bash

exec php /xampp/htdocs/WebSocket/src/main/ServerImpl.php
