<?php
$output = shell_exec('php ServerImpl.php');
echo "<pre>$output</pre>";
?>